package com.macauris.gestionComunitaria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionComunitariaApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionComunitariaApplication.class, args);
	}

}
