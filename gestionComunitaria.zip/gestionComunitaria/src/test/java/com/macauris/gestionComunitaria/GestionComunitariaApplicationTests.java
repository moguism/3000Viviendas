package com.macauris.gestionComunitaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionComunitariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
